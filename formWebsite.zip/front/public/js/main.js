$(function () {
  $('.bs-timepicker').timepicker();
  $('.datepicker').datepicker();
  $('.grid').isotope({
    itemSelector: '.grid-item',
    masonry: {
      columnWidth: 100
    }
  });
  
});
$('.datepicker').datepicker();
